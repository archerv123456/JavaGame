package com.tutorial.main;

public enum ID {
	
	Player(),
	Player2(),
	Player3(),
	Player4(),
	BasicEnemy(),
	HardEnemy(),
	LunaiticEnemy(),
	FastEnemy(),
	Friend(),
	ShooterEnemy(),
	SmartEnemy(),
	EnemyBoss(),
	MenuParticle(),
	EnemyBoss2(),
	Trail();
	
}
